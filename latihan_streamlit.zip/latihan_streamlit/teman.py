import streamlit as st 

st.image("jamet.jpeg", caption="I love u oll")
st.image("hasna.jpeg", caption="Hasnaa ttp jd tmn aku karna masih banyak wishlist yg blm kita laksanain yak")
st.image("hasna2.jpeg", caption="Sahabat sepertimu adalah hadiah berharga yang selalu membuat hidupku lebih indah Terima kasih sudah selalu ada!Kita mungkin tidak selalu sempurna, tapi persahabatan kita adalah hal paling sempurna yang pernah aku miliki")