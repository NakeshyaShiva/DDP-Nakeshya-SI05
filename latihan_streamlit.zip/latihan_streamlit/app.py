import streamlit as st 

st.title('hello mabro')
st.image('images.jpg', caption="ini gambar")

st.image('baloons.jpg', caption="Ini balon aku")

dashboard = st.Page("./fitur/dashboard.py",title="dashboard)")
Menabung = st.Page("./fitur/Menabung.py", title="Menabung")

pg = st.navigation(
    {
      "Menu Utama" : [dashboard],
      "Transaksi" : [Menabung],

    }
)

if 'total_semua' not in st.session_state:
    st.session_state['total semua'] = []
pg.run()