import streamlit as st 

st.title("Halaman Menabung")

# Formulir input 
with st.form("Menabung"):
    Nama = st.text_input("Nama")
    Jumlah = st.number_input("Jumlah (Rp.)", min_value=0)
    Tanggal = st.date_input("Tanggal")
    Waktu = st.time_input("Waktu")
    submit_button = st.form_submit_button(label="Menabung")

    if submit_button and Jumlah >= 50000:
        st.session_state['total semua'].append({
            'Tipe' : 'Menabung',
            'Jumlah ' : Jumlah
        })
        st.success("Menabung berhasil")
    else:
        st.error("Menabung gagal")